from django.contrib import admin

# Register your models here.
#user_login , user_details , user_soil_query , user_plant_query , disease_master
# fertilizer_master , disease_fertilizer_map , user_admin_query , notice_board

from .models import user_login, user_details, user_soil_query , user_plant_query , disease_master

from.models import fertilizer_master , disease_fertilizer_map , user_admin_query , notice_board
#from.models import user_details


admin.site.register(user_login)
admin.site.register(user_details)
admin.site.register(user_soil_query )
admin.site.register(user_plant_query )
admin.site.register(disease_master)
admin.site.register(fertilizer_master )
admin.site.register(disease_fertilizer_map )
admin.site.register(user_admin_query )
admin.site.register(notice_board)