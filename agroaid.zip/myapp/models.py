from django.db import models

# Create your models here.

# 1. user_login - id, uname, passwd, u_type
# 2. user_details - id, user_id ,fname ,lname,gender,dob,addr,pin,contact,email
# 3. user_soil_query - id , user_id, N,P,K,temperature,humidity,ph,rainfall,result, dt, tm
# 4. user_plant_query - id, user_id, pic_path, result, dt, tm
# 5. disease_master - id, crop, disease
# 6. fertilizer_master - id, disease_id, fertilizer_name, company_name, url
# 7. disease_fertilizer_map - id, disease_id, fertilizer_id
# 8. user_admin_query - id, user_id, query, reply, dt, tm, r_dt, r_tm, status
# 9. notice_board - id, title, pic_path, descp, dt, tm, status

# 1. user_login - id, uname, passwd, u_type
class user_login(models.Model):
    uname = models.CharField(max_length=100)
    passwd = models.CharField(max_length=25)
    u_type = models.CharField(max_length=10)

    def __str__(self):
        return self.uname

# 2. user_details - id, user_id ,fname ,lname,gender,dob,addr,pin,contact,email
class user_details(models.Model):
    user_id = models.IntegerField()
    fname = models.CharField(max_length=100)
    lname = models.CharField(max_length=200)
    gender = models.CharField(max_length=25)
    dob = models.CharField(max_length=25)
    addr = models.CharField(max_length=500)
    pin = models.IntegerField()
    contact = models.CharField(max_length=25)
    email = models.CharField(max_length=25)

    def __str__(self):
        return self.fname

# 3. user_soil_query - id , user_id, N,P,K,temperature,humidity,ph,rainfall,result, dt, tm
class user_soil_query(models.Model):
    #id
    user_id = models.IntegerField()
    N = models.FloatField()
    P = models.FloatField()
    K = models.FloatField()
    temperature = models.FloatField()
    humidity = models.FloatField()
    ph = models.FloatField()
    rainfall = models.FloatField()
    result = models.CharField(max_length=25)
    dt = models.CharField(max_length=25)
    tm = models.CharField(max_length=25)

# 4. user_plant_query - id, user_id, pic_path, result, dt, tm
class user_plant_query(models.Model):
    #id
    user_id = models.IntegerField()
    pic_path = models.CharField(max_length=250)
    result = models.CharField(max_length=25)
    dt = models.CharField(max_length=25)
    tm = models.CharField(max_length=25)
    status = models.CharField(max_length=25)

# 5. disease_master - id, crop, disease
class disease_master(models.Model):
    #id
    crop = models.CharField(max_length=100)
    disease = models.CharField(max_length=150)

# 6. fertilizer_master - id, fertilizer_name, company_name, url
class fertilizer_master(models.Model):
    #id
    disease_id = models.IntegerField()
    fertilizer_name = models.CharField(max_length=150)
    company_name = models.CharField(max_length=100)
    url = models.CharField(max_length=250)

# 7. disease_fertilizer_map - id, disease_id, fertilizer_id
class disease_fertilizer_map(models.Model):
    #id
    disease_id = models.IntegerField()
    fertilizer_id = models.IntegerField()

# 8. user_admin_query - id, user_id, query, reply, dt, tm, r_dt, r_tm, status
class user_admin_query(models.Model):
    #id
    user_id = models.IntegerField()
    query = models.CharField(max_length=250)
    reply = models.CharField(max_length=250)
    dt = models.CharField(max_length=25)
    tm = models.CharField(max_length=25)
    r_dt = models.CharField(max_length=25)
    r_tm = models.CharField(max_length=25)
    status = models.CharField(max_length=25)

# 9. notice_board - id, title, pic_path, descp, dt, tm, status
class notice_board(models.Model):
    #id
    title = models.CharField(max_length=150)
    pic_path = models.CharField(max_length=250)
    descp = models.CharField(max_length=450)
    dt = models.CharField(max_length=25)
    tm = models.CharField(max_length=25)
    status = models.CharField(max_length=25)
