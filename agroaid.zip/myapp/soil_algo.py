# import os
# import numpy as np
import pandas as pd
from sklearn import tree, model_selection, metrics

def predict_result(rule_file, val1,val2,val3,val4,val5,val6,val7 ):

    data = pd.read_csv(rule_file,
                       names=['N','P','K','temperature','humidity','ph','rainfall','label'])
    #'val1', 'val2', 'val3', 'val4', 'val5', 'val6', 'val7','class'])

    data['label'], class_names = pd.factorize(data['label'])
    #print("Class = {}".format(class_names))
    #print(data['class'].unique())


    ####################################################
    d_class = dict()
    i = 0
    for n in class_names:
        ll = data['label'].unique()[i]
        d_class[n] = ll
        i += 1
    #print(d_class)


    ######################################################
    # print(data.head())
    # print(data.info())

    X = data.iloc[:, :-1]
    y = data.iloc[:, -1]

    # split data randomly into 70% training and 30% test
    X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=0.3, random_state=0)

    # train the decision tree
    dtree = tree.DecisionTreeClassifier(criterion='entropy', max_depth=None, random_state=None)
    dtree.fit(X_train.values, y_train.values)

    tx = [
        val1,val2,val3,val4,val5,val6,val7
         ]

    y_pred = dtree.predict([tx])
    #print("{} -> \t {}".format(tx, class_names[y_pred[0]]))
    return class_names[y_pred[0]]

if __name__ == '__main__':
    rule_file = '../data/crop_dataset.csv'  #'../data/data_set.csv'

    #N,P,K,temperature,humidity,ph,rainfall,label

    result = predict_result(rule_file,83,45,21,18.83344471,58.75082029,5.716222912,79.75328959999999)#90,42,43,20.87974371,82.00274423,6.502985292000001,202.9355362)
    print(result)
'''
from .ml_algo import predict_result

    ############### ML PART ###############
        data_file_path = os.path.join(BASE_DIR, 'data/data_set.csv')
        result = predict_result(data_file_path,
                        float(age),float(sex),float(cp),float(trestbps),
                        float(chol),float(fbs),float(restecg),float(thalach),
                        float(exang),float(oldpeak),float(slope),float(ca),float(thal))

        print(result)

        ######################################
'''
