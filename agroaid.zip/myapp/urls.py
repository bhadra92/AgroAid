"""project URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from . import views
from django.urls import path

urlpatterns = [
    path('', views.index, name='index'),
    path('index', views.index, name='index'),
    path('about', views.about, name='about'),
    path('contact', views.contact, name='contact'),
    path('test', views.test, name='test'),

    path('admin_login', views.admin_login, name='admin_login'),
    path('admin_changepassword', views.admin_changepassword, name='admin_changepassword'),
    path('admin_logout', views.admin_logout, name='admin_logout'),
    path('admin_home', views.admin_home, name='admin_home'),

    path('admin_user_view', views.admin_user_view, name='admin_user_view'),
    path('admin_user_delete', views.admin_user_delete, name='admin_user_delete'),

    path('admin_disease_master_add', views.admin_disease_master_add, name='admin_disease_master_add'),
    path('admin_disease_master_delete', views.admin_disease_master_delete, name='admin_disease_master_delete'),
    path('admin_disease_master_view', views.admin_disease_master_view, name='admin_disease_master_view'),

    path('admin_fertilizer_master_add', views.admin_fertilizer_master_add, name='admin_fertilizer_master_add'),
    path('admin_fertilizer_master_delete', views.admin_fertilizer_master_delete, name='admin_fertilizer_master_delete'),
    path('admin_fertilizer_master_view', views.admin_fertilizer_master_view, name='admin_fertilizer_master_view'),

    path('admin_notice_board_add', views.admin_notice_board_add, name='admin_notice_board_add'),
    path('admin_notice_board_delete', views.admin_notice_board_delete, name='admin_notice_board_delete'),
    path('admin_notice_board_view', views.admin_notice_board_view, name='admin_notice_board_view'),

    path('admin_user_query_view', views.admin_user_query_view, name='admin_user_query_view'),
    path('admin_user_query_pending_view', views.admin_user_query_pending_view, name='admin_user_query_pending_view'),
    path('admin_user_query_reply', views.admin_user_query_reply, name='admin_user_query_reply'),



    path('user_login', views.user_login_check, name='user_login'),
    path('user_logout', views.user_logout, name='user_logout'),
    path('user_home', views.user_home, name='user_home'),
    path('user_details_add', views.user_details_add, name='user_details_add'),
    path('user_changepassword', views.user_changepassword, name='user_changepassword'),

    path('user_notice_board_view', views.user_notice_board_view, name='user_notice_board_view'),

    path('user_soil_query_add', views.user_soil_query_add, name='user_soil_query_add'),
    path('user_soil_query_view', views.user_soil_query_view, name='user_soil_query_view'),

    path('user_plant_query_add', views.user_plant_query_add, name='user_plant_query_add'),
    path('user_plant_query_view', views.user_plant_query_view, name='user_plant_query_view'),

    path('user_fertilizer_master_view', views.user_fertilizer_master_view, name='user_fertilizer_master_view'),

    path('user_admin_query_add', views.user_admin_query_add, name='user_admin_query_add'),
    path('user_user_admin_query_delete', views.user_user_admin_query_delete, name='user_user_admin_query_delete'),
    path('user_admin_query_view', views.user_admin_query_view, name='user_admin_query_view'),
    path('user_admin_query_pending_view', views.user_admin_query_pending_view, name='user_admin_query_pending_view'),
]
