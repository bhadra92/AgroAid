from django.shortcuts import render

# Create your views here.
from django.db.models import Max
from .models import user_login

def index(request):
    return render(request, './myapp/index.html')


def about(request):
    return render(request, './myapp/about.html')


def contact(request):
    return render(request, './myapp/contact.html')

def test(request):
    return render(request, './myapp/test.html')

###################### ADMIN #####################################
def admin_login(request):
    if request.method == 'POST':
        un = request.POST.get('un')
        pwd = request.POST.get('pwd')
        #print(un,pwd)
        #query to select a record based on a condition
        ul = user_login.objects.filter(uname=un, passwd=pwd, u_type='admin')

        if len(ul) == 1:
            request.session['user_name'] = ul[0].uname
            request.session['user_id'] = ul[0].id
            return render(request,'./myapp/admin_home.html')
        else:
            msg = 'Invalid Uname or Password !!!'
            context ={ 'msg':msg }
            return render(request, './myapp/admin_login.html',context)
    else:
        msg = ''
        context ={ 'msg':msg }
        return render(request, './myapp/admin_login.html',context)


def admin_home(request):
    try:
        uname = request.session['user_name']
        print(uname)
    except:
        return admin_login(request)
    else:
        return render(request,'./myapp/admin_home.html')


def admin_logout(request):
    try:
        del request.session['user_name']
        del request.session['user_id']
    except:
        return admin_login(request)
    else:
        return admin_login(request)

def admin_changepassword(request):
    if request.method == 'POST':
        opasswd = request.POST.get('opasswd')
        npasswd = request.POST.get('npasswd')
        cpasswd = request.POST.get('cpasswd')
        uname = request.session['user_name']
        try:
            ul = user_login.objects.get(uname=uname,passwd=opasswd,u_type='admin')
            if ul is not None:
                ul.passwd=npasswd
                ul.save()
                context = {'msg': 'Password Changed'}
                return render(request, './myapp/admin_changepassword.html', context)
            else:
                context = {'msg': 'Password Not Changed'}
                return render(request, './myapp/admin_changepassword.html', context)
        except user_login.DoesNotExist:
            context = {'msg': 'Password Err Not Changed'}
            return render(request, './myapp/admin_changepassword.html', context)
    else:
        context = {'msg': ''}
        return render(request, './myapp/admin_changepassword.html', context)
from .models import user_details
def admin_user_view(request):
    ul_l = user_login.objects.filter(u_type='user')

    tm_l = []
    for u in ul_l:
        ud = user_details.objects.filter(user_id=u.id).first()
        if ud:
            tm_l.append(ud)

    context = {'user_list':tm_l,'type':'User Details'}
    return render(request, './myapp/admin_user_view.html',context)

def admin_user_delete(request):
    id = request.GET.get('id')
    print("id="+id)

    nm = user_details.objects.get(id=int(id))
    u_l = user_login.objects.get(id= nm.user_id)
    u_l.delete()
    nm.delete()

    ul_l = user_login.objects.filter(u_type='user')

    tm_l = []
    for u in ul_l:
        ud = user_details.objects.get(user_id=u.id)
        tm_l.append(ud)

    context = {'user_list': tm_l, 'type': 'User Details','msg':'User Removed'}
    return render(request, './myapp/admin_user_view.html', context)

# 5. disease_master - id, crop, disease
from .models import disease_master
def admin_disease_master_add(request):
    if request.method == 'POST':
        crop = request.POST.get('crop')
        disease = request.POST.get('disease')
        cm = disease_master(disease=disease,crop=crop)
        cm.save()
        context = {'msg': 'Disease Record Added'}
        return render(request, 'myapp/admin_disease_master_add.html', context)

    else:
        return render(request, 'myapp/admin_disease_master_add.html')

def admin_disease_master_delete(request):
    id = request.GET.get('id')
    print("id="+id)

    nm = disease_master.objects.get(id=int(id))
    nm.delete()

    nm_l = disease_master.objects.all()
    context ={'disease_list':nm_l}
    return render(request,'myapp/admin_disease_master_view.html',context)

def admin_disease_master_view(request):
    nm_l = disease_master.objects.all()
    context = {'disease_list': nm_l}
    return render(request, 'myapp/admin_disease_master_view.html', context)

from .models import notice_board
from django.core.files.storage import FileSystemStorage
from datetime import datetime
# 9. notice_board - id, title, pic_path, descp, dt, tm, status
def admin_notice_board_add(request):
    if request.method == 'POST':
        u_file = request.FILES['document']
        fs = FileSystemStorage()
        path = fs.save(u_file.name, u_file)

        pic_path = path

        title = request.POST.get('title')
        descp = request.POST.get('descp')

        dt = datetime.today().strftime('%Y-%m-%d')
        tm = datetime.today().strftime('%H:%M:%S')
        status = "PENDING"


        nd = notice_board(title=title,descp=descp,pic_path=pic_path,
                          dt=dt,tm=tm,status=status)
        nd.save()


        context = {'msg': 'News Record Added'}
        return render(request, './myapp/admin_notice_board_add.html', context)
    else:

        context = {'msg': ''}
        return render(request, './myapp/admin_notice_board_add.html', context)

def admin_notice_board_delete(request):
    id = request.GET.get('id')
    print('id = ' + id)
    nd = notice_board.objects.get(id=int(id))
    nd.delete()

    news_list = notice_board.objects.all()
    context = {'news_list': news_list, 'msg': 'News Deleted'}
    return render(request, './myapp/admin_notice_board_view.html', context)


def admin_notice_board_view(request):
    news_list = notice_board.objects.all()
    context = {'news_list': news_list }
    return render(request, './myapp/admin_notice_board_view.html',context)

# 6. fertilizer_master - id, disease_id, fertilizer_name, company_name, url
from .models import fertilizer_master
def admin_fertilizer_master_add(request):
    if request.method == 'POST':

        fertilizer_name = request.POST.get('fertilizer_name')
        disease_id = request.POST.get('disease_id')
        company_name = request.POST.get('company_name')
        url=request.POST.get('url')

        f_obj = fertilizer_master(fertilizer_name=fertilizer_name, disease_id=disease_id,
                                       company_name=company_name,url=url)
        f_obj.save()

        # print(user_id)
        dm_l = disease_master.objects.all()
        context = {'disease_list': dm_l, 'msg': 'Fertilizer Added'}
        return render(request, 'myapp/admin_fertilizer_master_add.html', context)

    else:
        dm_l = disease_master.objects.all()
        context = {'disease_list': dm_l}
        return render(request, 'myapp/admin_fertilizer_master_add.html',context)


def admin_fertilizer_master_view(request):
    fm_l = fertilizer_master.objects.all()
    dm_l = disease_master.objects.all()
    context = {'fertilizer_list': fm_l, 'disease_list': dm_l}
    return render(request, './myapp/admin_fertilizer_master_view.html', context)


def admin_fertilizer_master_delete(request):
    id = int(request.GET.get('id'))
    f_obj = fertilizer_master.objects.get(id=id)
    f_obj.delete()

    fm_l = fertilizer_master.objects.all()
    dm_l = disease_master.objects.all()
    context = {'fertilizer_list': fm_l, 'disease_list': dm_l, 'msg':'Fertilizer Deleted'}
    return render(request, './myapp/admin_fertilizer_master_view.html', context)

from .models import user_admin_query

def admin_user_query_pending_view(request):


    pm_l = user_admin_query.objects.filter(status='PENDING')

    ar_l = user_details.objects.all()
    context ={'user_list':ar_l,'message_list': pm_l,'msg':''}
    return render(request,'myapp/admin_user_query_view.html',context)


def admin_user_query_view(request):
    pm_l = user_admin_query.objects.filter(status='ok')

    ar_l = user_details.objects.all()
    context = {'user_list': ar_l, 'message_list': pm_l, 'msg': ''}
    return render(request, 'myapp/admin_user_query_view.html', context)


def admin_user_query_reply(request):
    if request.method == 'POST':

        user_id = request.session['user_id']
        message_id = int(request.POST.get('message_id'))
        reply = request.POST.get('reply')
        r_dt = datetime.today().strftime('%Y-%m-%d')
        r_tm = datetime.today().strftime('%H:%M:%S')
        suc = user_admin_query.objects.get(id=int(message_id))
        suc.reply = reply
        suc.status = 'ok'
        suc.r_tm=r_tm
        suc.r_dt =r_dt
        suc.save()

        pm_l = user_admin_query.objects.filter(status='ok')

        ar_l = user_details.objects.all()
        context = {'user_list': ar_l, 'message_list': pm_l, 'msg': ''}
        return render(request, 'myapp/admin_user_query_view.html', context)
    else:

        message_id = int(request.GET.get('id'))

        context = { 'message_id': message_id}
        return render(request, './myapp/admin_user_query_reply.html', context)

#####################################################################
############################# USER ##########################
from .models import user_details

def user_login_check(request):
    if request.method == 'POST':
        uname = request.POST.get('uname')
        passwd = request.POST.get('passwd')

        ul = user_login.objects.filter(uname=uname, passwd=passwd, u_type='user')
        print(len(ul))
        if len(ul) == 1:
            request.session['user_id'] = ul[0].id
            request.session['user_name'] = ul[0].uname
            context = {'uname': request.session['user_name']}
            #send_mail('Login','welcome'+uname,uname)
            return render(request, 'myapp/user_home.html',context)
        else:
            context = {'msg': 'Invalid Credentials'}
            return render(request, 'myapp/user_login.html',context)
    else:
        return render(request, 'myapp/user_login.html')

def user_home(request):

    context = {'uname':request.session['user_name']}
    return render(request,'./myapp/user_home.html',context)
    #send_mail("heoo", "hai", 'snehadavisk@gmail.com')

def user_details_add(request):
    if request.method == 'POST':

        fname = request.POST.get('fname')
        lname = request.POST.get('lname')

        gender = request.POST.get('gender')
        dob = request.POST.get('dob')
        addr = request.POST.get('addr')
        pin = request.POST.get('pin')
        email = request.POST.get('email')
        contact = request.POST.get('contact')
        password = request.POST.get('pwd')
        uname=email
        #status = "new"

        ul = user_login(uname=uname, passwd=password, u_type='user')
        ul.save()
        user_id = user_login.objects.all().aggregate(Max('id'))['id__max']

        ud = user_details(user_id=user_id,fname=fname, lname=lname, gender=gender, dob=dob,addr=addr, pin=pin, contact=contact, email=email )
        ud.save()

        print(user_id)
        context = {'msg': 'User Registered'}
        return render(request, 'myapp/user_login.html',context)

    else:
        return render(request, 'myapp/user_details_add.html')

def user_changepassword(request):
    if request.method == 'POST':
        uname = request.session['user_name']
        new_password = request.POST.get('new_password')
        current_password = request.POST.get('current_password')
        print("username:::" + uname)
        print("current_password" + str(current_password))

        try:

            ul = user_login.objects.get(uname=uname, passwd=current_password)

            if ul is not None:
                ul.passwd = new_password  # change field
                ul.save()
                context = {'msg':'Password Changed Successfully'}
                return render(request, './myapp/user_changepassword.html',context)
            else:
                context = {'msg': 'Password Not Changed'}
                return render(request, './myapp/user_changepassword.html', context)
        except user_login.DoesNotExist:
            context = {'msg': 'Password Not Changed'}
            return render(request, './myapp/user_changepassword.html', context)
    else:
        return render(request, './myapp/user_changepassword.html')



def user_logout(request):
    try:
        del request.session['user_name']
        del request.session['user_id']
    except:
        return user_login_check(request)
    else:
        return user_login_check(request)

def user_notice_board_view(request):
    news_list = notice_board.objects.all()
    context = {'news_list': news_list }
    return render(request, './myapp/user_notice_board_view.html',context)

import os
from project.settings import BASE_DIR
from.models import user_soil_query

from .soil_algo import predict_result
# 3. user_soil_query - id , user_id, N,P,K,temperature,humidity,ph,rainfall,result, dt, tm
def user_soil_query_add(request):
    if request.method == 'POST':

        user_id = int(request.session['user_id'])
        N = request.POST.get('N')
        P = request.POST.get('P')
        K = request.POST.get('K')
        temperature = request.POST.get('temperature')
        humidity = request.POST.get('humidity')
        ph = request.POST.get('ph')
        rainfall = request.POST.get('rainfall')
        dt = datetime.today().strftime('%Y-%m-%d')
        tm = datetime.today().strftime('%H:%M:%S')
        result ='Normal'
        #######################################
        ############### ML PART ###############
        data_file_path = os.path.join(BASE_DIR, 'data/crop_dataset.csv')
        result = predict_result(data_file_path,
                        float(N),float(P),float(K),float(temperature),
                        float(humidity),float(ph),float(rainfall))
        print(result)
        ######################################

        data_obj = user_soil_query(user_id=user_id,result=result, dt=dt,tm=tm,
                                   N=N, P=P, K=K, temperature=temperature,
                                   humidity=humidity, ph=ph, rainfall=rainfall,
                                   )
        data_obj.save()


        context = {'user_id': user_id,'msg':f'Record added result = {result}' }
        return render(request, 'myapp/user_soil_query_add.html',context)
    else:
        context ={'msg': ''}
        return render(request, 'myapp/user_soil_query_add.html',context)


def user_soil_query_view(request):
    user_id = int(request.session['user_id'])
    pp_l = user_soil_query.objects.filter(user_id=user_id)
    ud_l = user_details.objects.all()
    context = {'test_list': pp_l, 'user_list': ud_l}
    return render(request, 'myapp/user_soil_query_view.html', context)

from .models import user_plant_query
# 4. user_plant_query - id, user_id, pic_path, result, dt, tm
from .image_classify import predict
def user_plant_query_add(request):
    if request.method == 'POST':
        u_file = request.FILES['document']
        fs = FileSystemStorage()
        path = fs.save(u_file.name, u_file)

        pic_path = path
        user_id =int(request.session['user_id'])

        dt = datetime.today().strftime('%Y-%m-%d')
        tm = datetime.today().strftime('%H:%M:%S')
        result=''
        status = 'yes'
        ##############INCEPTION ALGO PART#############
        infile = f'./myapp/static/myapp/media/{pic_path}'
        inception_result = predict(BASE_DIR, infile)

        ##############################################
        result = inception_result
        if 'healthy' in result:
            status='no'
        nd = user_plant_query(user_id=user_id,result=result,pic_path=pic_path,
                          dt=dt,tm=tm,status=status)
        nd.save()


        context = {'msg': f'Disease Analysed and Result={result}'}
        return render(request, './myapp/user_plant_query_add.html', context)
    else:

        context = {'msg': ''}
        return render(request, './myapp/user_plant_query_add.html', context)

def user_plant_query_view(request):
    user_id = int(request.session['user_id'])
    pp_l = user_plant_query.objects.filter(user_id=user_id)
    ud_l = user_details.objects.all()
    context = {'query_list': pp_l, 'user_list': ud_l}
    return render(request, 'myapp/user_plant_query_view.html', context)

def user_fertilizer_master_view(request):
    id = request.GET.get('id')
    upq = user_plant_query.objects.get(id=int(id))
    r_st = upq.result.split(' ')
    c_st = r_st[0]
    d_st = ' '.join(r_st[1:])
    print(c_st,d_st)
    dm_obj = disease_master.objects.filter(crop__iexact=c_st, disease__iexact=d_st).first()
    if dm_obj:
        fm_l = fertilizer_master.objects.filter(disease_id=dm_obj.id)
        dm_l = disease_master.objects.all()
        context = {'fertilizer_list': fm_l, 'disease_list': dm_l}
    else:
        context = {'msg': 'No Fertilizer Linked'}
    return render(request, './myapp/user_fertilizer_master_view.html', context)


# 8. user_admin_query - id, user_id, query, reply, dt, tm, r_dt, r_tm, status
def user_admin_query_add(request):
    if request.method == 'POST':

        query = request.POST.get('query')
        reply = 'no remarks'
        user_id = request.session['user_id']
        dt = datetime.today().strftime('%Y-%m-%d')
        tm = datetime.today().strftime('%H:%M:%S')
        r_dt =' '
        r_tm =' '
        pm = user_admin_query(user_id=int(user_id),r_dt=r_dt, r_tm=r_tm,
                           query=query,reply=reply,dt=dt,tm=tm,status='PENDING' )
        pm.save()

        context = {'msg':'Record added'}
        return render(request, 'myapp/user_admin_query_add.html',context)

    else:

        context = {'msg':''}
        return render(request, 'myapp/user_admin_query_add.html',context)

def user_user_admin_query_delete(request):
    id = request.GET.get('id')
    print("id="+id)

    pm = user_admin_query.objects.get(id=int(id))
    pm.delete()


    user_id = request.session['user_id']
    pm_l = user_admin_query.objects.filter(user_id=int(user_id),status='ok')
    ar_l = user_details.objects.all()
    context ={'user_list':ar_l,'query_list': pm_l,'msg':'Record deleted'}
    return render(request,'myapp/user_admin_query_view.html',context)

def user_admin_query_view(request):

    user_id = request.session['user_id']
    pm_l = user_admin_query.objects.filter(user_id=int(user_id),status='ok')
    ar_l = user_details.objects.all()
    context ={'user_list':ar_l,'query_list': pm_l,'msg':''}
    return render(request,'myapp/user_admin_query_view.html',context)

def user_admin_query_pending_view(request):

    user_id = request.session['user_id']
    pm_l = user_admin_query.objects.filter(user_id=int(user_id),status='PENDING')
    ar_l = user_details.objects.all()
    context ={'user_list':ar_l,'query_list': pm_l,'msg':''}
    return render(request,'myapp/user_admin_query_view.html',context)



###########################################################
'''
##############INCEPTION ALGO PART#############
    infile = f'./myapp/static/myapp/media/{np.pic_path}'
    inception_result = predict(BASE_DIR, infile)

    ##############################################
'''
#############################################################
